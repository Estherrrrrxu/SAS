
class LinearReservoir:
    pass